#set ($component = ${StringUtils.removeAndHump(${NAME}, "-")})
#set ($propType = "${component}Props")

import React, { FC } from "react"
import styles from "./${NAME}.module.less"

export interface $propType {}

const $component: FC<$propType> = () => {
#[[$END$]]#
  return <div></div>
}

export default $component